const posts = [
    { title: ' Post 1 ', body: ' this is post 1'},
    { title: ' Post 2 ', body: ' this is post 2'},
];

function getPosts() {
    
    setTimeout( () => {
        let output = '';

        posts.forEach( (post, index) => {
            output += `<li>${post.title}</li>`;
        } );
    
        document.body.innerHTML = output;
    }, 1000);
}

function createPost( post ) {
    return new Promise( (resolve, reject ) =>{
        setTimeout( () =>{
            
            posts.push(post);

            let error = false;

            if (!error)  { // הכל תקין
                resolve();
            } else { // יש תקלה
                reject("Hey! Are you crazy!!!! there is an ERROR! stop pushing!");
            }
       }, 2000);
    } );
}

const promise1 = Promise.resolve('hello world');
const promise2 = 10;
const promise3 = new Promise( (resolve,reject)=> {
    setTimeout(resolve,2000,'Good Bye')
} );

Promise.all([promise1, promise2, promise3]).then(values => console.log(values));

// createPost( { title: 'Post 3', body: 'this is post 3'} )
//     .then(getPosts)
//     .catch((errorDetails) => console.log("ERROR: " + errorDetails)  );

