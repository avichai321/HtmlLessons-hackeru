const posts = [
    { title: ' Post 1 ', body: ' this is post 1'},
    { title: ' Post 2 ', body: ' this is post 2'},
];

function getPosts() {
    
    setTimeout( () => {
        let output = '';

        posts.forEach( (post, index) => {
            output += `<li>${post.title}</li>`;
        } );
    
        document.body.innerHTML = output;
    }, 1000);
}

function createPost( post ) {
    return new Promise( (resolve, reject ) =>{
        setTimeout( () =>{
            
            posts.push(post);

            let error = true;

            if (!error)  { // הכל תקין
                resolve();
            } else {
                reject("Hey! Are you crazy!!!! there is an ERROR! stop pushing!");
            }
       }, 2000);
    } );
}

createPost( { title: 'Post 3', body: 'this is post 3'} )
    .then(getPosts)
    .catch((errorDetails) => console.log("ERROR: " + errorDetails)  );

